use [CRM01]
go

select count(*) as 'USER-COUNT' from [dbo].[Users];
go
