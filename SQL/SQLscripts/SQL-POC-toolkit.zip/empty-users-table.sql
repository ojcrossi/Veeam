use [CRM01]
go

truncate table [dbo].[users];
go
